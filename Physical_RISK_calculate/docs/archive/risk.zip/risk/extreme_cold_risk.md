# 한파 물리적 리스크 계산 (Extreme Cold Risk)

## 📋 개요

사업장 좌표(위도, 경도)를 기반으로 **한파 물리적 리스크**를 계산합니다.

**리스크 모델**: `Risk = H (Hazard) × E (Exposure) × V (Vulnerability)`

- **H (Hazard)**: 기후 자체의 위험 강도 (한파 발생 빈도 및 강도)
- **E (Exposure)**: 사업장이 놓인 자연환경 기반 물리적 노출도
- **V (Vulnerability)**: 사업장의 사회·인프라 기반 취약성

---

## ❄️ 1. H (Hazard) - 기후 위험도

### 데이터 소스
- **CMIP6 SSP 시나리오** (미래 기후 예측)
- **일최저기온(TN)** 데이터

### 계산 방법
현재는 하드코딩 값 사용 (향후 NetCDF에서 추출 예정)

```python
H_norm = 0.4520  # 2030년 SSP126 시나리오 기준 (일최저기온)
```

### 해석
- **0~1 범위**로 정규화
- 값이 클수록 한파 위험도 높음
- SSP126: 저탄소 시나리오

---

## 🌿 2. E (Exposure) - 환경 노출도

사업장 중심 **반경 1km 버퍼** 내의 자연환경 특성을 분석합니다.

### 2-1. 토지피복 (Land Cover)

#### 데이터 소스
- **환경부 토지피복도** (ME_GROUNDCOVERAGE_50000)
- 격자: 1:50,000 축척
- 파일: `shared_data/landcover/ME_GROUNDCOVERAGE_50000/37709.tif`

#### 분류 체계 (한파 관점)
| 코드 | 분류 | 한파 영향 |
|------|------|-----------|
| 0, 1 | 시가화건조지역 (불투수면) | 열 유지 ↑ (보호) |
| 2 | 농업지역 (논·밭) | 개방지 → 취약 |
| 3 | 산림지역 | 보온 효과 약함 |
| 4 | 초지 | 개방지 → 매우 취약 |
| 5 | 습지 | 습기 → 체감온도 ↓ |
| 6 | 나지 | 개방지 → 매우 취약 |
| 7 | 수역 | 열 완충 효과 있음 |

#### 계산식

```python
# 1km 버퍼 내 픽셀 집계
imperv_ratio = (시가화건조지역 픽셀 수) / (전체 픽셀 수)
green_ratio = (산림 + 농업 + 초지 픽셀 수) / (전체 픽셀 수)
open_ratio = (초지 + 나지 픽셀 수) / (전체 픽셀 수)

# E 지표 계산
E_open_exposure = open_ratio  # 개방지 많을수록 취약 (바람 노출)
E_imperv_lack = 1.0 - imperv_ratio  # 불투수면 적을수록 취약 (열 유지 못함)
E_green_exposure = green_ratio  # 녹지 많을수록 취약 (보온 효과 부족)
```

#### 해석
- **개방지(초지·나지) ↑** → 바람 노출 ↑ → 한파 위험 ↑
- **불투수면 ↓** → 열 유지 못함 → 한파 위험 ↑
- **녹지 ↑** → 보온 효과 부족 → 한파 위험 ↑

**⚠️ 폭염과 정반대!**

---

### 2-2. DEM (Digital Elevation Model)

#### 데이터 소스
- **국토지리정보원 공개 DEM**
- 해상도: 30m
- 파일: `shared_data/DEM/seoul_dem_merged.tif`
- CRS: EPSG:5186 (TM 중부원점)

#### 계산 방법

```python
# 1km 버퍼 내 고도 평균 계산
elevation_mean = np.mean(buffer_내_DEM_픽셀)

# 고도 정규화 (0~300m 범위)
elevation_norm = elevation_mean / 300.0

# 한파: 고지대일수록 취약 (추위가 심함)
E_elevation = elevation_norm  # 높을수록 취약 (폭염과 반대!)
```

#### 근거
- **고지대** (200m+):
  - 기온감률: 고도 100m 상승 시 약 0.6°C 하강
  - 바람 강도 증가
  - 한파 취약도 **높음**

- **저지대** (0~50m):
  - 상대적으로 온난
  - 도시 열섬 잔열 효과
  - 한파 취약도 **낮음**

#### 예시 결과
```
✅ 평균 고도: 41.5m
   범위: 17.3~114.2m
   E_elevation: 0.1384 (높을수록 취약)
```
→ 개포동은 평균 41.5m 저지대로, 한파에 **상대적으로 안전**

**⚠️ 폭염과 정반대!**
- 폭염 E_elevation: 0.8616 (저지대 = 취약)
- 한파 E_elevation: 0.1384 (저지대 = 안전)

---

### 2-3. E_cold 통합

최종 노출도:

```python
E_cold = 0.3 × E_open_exposure
       + 0.2 × E_imperv_lack
       + 0.3 × E_green_exposure
       + 0.2 × E_elevation
```

#### 가중치 근거
- **개방지 노출 (30%)**: 바람 한기 직접 영향
- **도시화 부족 (20%)**: 열 유지 능력 저하
- **녹지 노출 (30%)**: 보온 효과 부재
- **고지대 (20%)**: 기온감률 및 바람 강화

---

## 🏥 3. V (Vulnerability) - 취약성

### 3-1. 병원 접근성 (V_hospital)

#### 데이터 소스
- **국립중앙의료원 전국 병·의원 API**
- API Key: `PUBLIC_PORTAL_KEY` (환경변수)

#### 계산 방법

```python
# 가장 가까운 병원까지 거리 계산
nearest_hospital_km = min(사업장과_각_병원_간_거리)

# 거리 기반 취약도 (10km 기준)
V_hospital = clip(nearest_hospital_km / 10.0, 0, 1)
```

#### 근거
- 한파 시 저체온증·동상 응급환자 발생
- **거리 가까움** → 빠른 대응 가능 → 취약도 **낮음**
- **거리 멀음** → 대응 지연 → 취약도 **높음**

#### 예시
```
가장 가까운 병원: 강남성심한의원
거리: 0.16 km
V_hospital: 0.0160 (매우 낮음 - 우수한 접근성)
```

---

### 3-2. 건물 노후도 (V_building - 단열 상태)

#### 데이터 소스
- **국토교통부 건축HUB API** (건축물대장)
- API Key: `PUBLIC_PORTAL_KEY` (환경변수)

#### 계산 방법

```python
# 1km 버퍼 내 건물들의 나이 계산
building_age = 2024 - 준공연도

# 면적 가중 평균 나이
building_age_mean = Σ(건물_나이 × 연면적) / Σ(연면적)

# 노후도 취약도 (60년 기준)
V_building = clip(building_age_mean / 60.0, 0, 1)
```

#### 근거
- **신축 건물**: 단열/난방 성능 우수 → 취약도 **낮음**
- **노후 건물**: 단열/난방 성능 저하 → 취약도 **높음**

#### 예시
```
평균 건물 나이: 32.3년
V_building: 0.5383 (중간 수준 - 단열 성능 저하)
```

---

### 3-3. V_cold 통합

```python
V_cold = 0.5 × V_building + 0.5 × V_hospital
```

#### 가중치 근거
- **건물 노후도 (50%)**: 단열 성능 직접 영향
- **병원 접근성 (50%)**: 응급 대응 능력

---

## 🎯 4. 최종 리스크 계산

### 방법: 가중 평균형 (채택) ⭐
```python
gamma = 0.5
Risk = H × (gamma × E + (1 - gamma) × V)
```

#### 채택 근거
- 곱셈형: 한 요소가 0이면 전체 리스크 0 (비현실적)
- 가중 평균형: 각 요소의 기여도를 균형있게 반영

---

## 📊 5. 리스크 등급

| 점수 범위 | 등급 | 설명 |
|-----------|------|------|
| 0.7 ~ 1.0 | 🔴 매우 높음 | 즉각적인 대응 필요 |
| 0.5 ~ 0.7 | 🟠 높음 | 주의 및 대비 강화 |
| 0.3 ~ 0.5 | 🟡 중간 | 모니터링 필요 |
| 0.0 ~ 0.3 | 🟢 낮음 | 일반 관리 수준 |

---

## 🔥 6. 폭염 vs 한파 비교

### 개포동 (37.5172, 127.0473) 분석 결과

| 항목 | 폭염 (Heat) | 한파 (Cold) | 차이 |
|------|-------------|-------------|------|
| **H (Hazard)** | 0.3410 | 0.4520 | +32% |
| **평균 고도** | 41.5m | 41.5m | 동일 |
| **E_elevation** | 0.8616 (저지대=취약) | 0.1384 (저지대=안전) | **정반대** |
| **E (Exposure)** | 0.2240 | 0.5198 | +132% |
| **V (Vulnerability)** | 0.2772 | 0.2772 | 동일 |
| **최종 리스크** | 0.0855 | 0.1801 | **+111%** |
| **등급** | 🟢 낮음 | 🟢 낮음 | - |

### 핵심 인사이트

1. **개포동은 한파 리스크가 폭염의 2배**
   - 녹지 비율 82.8% → 한파에 취약
   - 불투수면 0% → 열 유지 못함

2. **DEM이 폭염/한파에 정반대 영향**
   - 저지대(41.5m)는 폭염에 취약, 한파에 안전
   - 고지대일수록 한파 위험 증가

3. **리스크 완화 방안**
   - 건물 단열 성능 강화 (V_building 개선)
   - 난방 시스템 고도화
   - 한파 대피소 접근성 향상

---

## 📁 7. 출력 파일

### 구조
```
Extreme_cold_RISK/
├── calculate_cold_risk.py      # 메인 스크립트
├── README.md                   # 본 문서
└── data/
    ├── api_cache/
    │   ├── exposure_data.json       # E 계산 상세 결과
    │   ├── hospital/
    │   │   └── hospital_data.json   # 병원 데이터
    │   └── building/
    │       └── building_data.json   # 건물 데이터
    └── results/
        └── extreme_cold_risk.json   # 최종 리스크 결과
```

### 결과 예시 (extreme_cold_risk.json)

```json
{
  "location": {
    "lat": 37.5172,
    "lon": 127.0473,
    "region": "서울특별시 강남구 개포동"
  },
  "year": 2030,
  "scenario": "SSP126",
  "components": {
    "H_norm": 0.4520,
    "E_cold": 0.5198,
    "V_building": 0.5383,
    "V_hospital": 0.0160,
    "V_cold": 0.2772
  },
  "risk_scores": {
    "multiplicative": 0.0651,
    "weighted": 0.1801,
    "final": 0.1801
  },
  "risk_level": "낮음 (Low)",
  "details": {
    "exposure": {
      "imperv_ratio": 0.0,
      "green_ratio": 0.828,
      "open_ratio": 0.146,
      "water_ratio": 0.026,
      "elevation_mean": 41.5,
      "E_open_exposure": 0.1462,
      "E_imperv_lack": 1.0,
      "E_green_exposure": 0.8277,
      "E_elevation": 0.1384,
      "E_cold": 0.5198
    }
  }
}
```

---

## 🔧 8. 사용 방법

### 환경 설정

1. **Python 패키지 설치**
```bash
pip install numpy pandas requests xmltodict rasterio shapely pyproj geopy
```

2. **환경 변수 설정** (`.env` 파일)
```bash
PUBLIC_PORTAL_KEY=your_api_key_here
```

### 실행

```bash
cd Extreme_cold_RISK
python3 calculate_cold_risk.py
```

### 커스터마이징

스크립트 내 변수 수정:

```python
# 분석 대상 위치
LAT = 37.5172
LON = 127.0473
REGION = "서울특별시 강남구 개포동"
YEAR = 2030
SCENARIO = "SSP126"
```

---

## 📚 9. 데이터 출처

| 데이터 | 출처 | 링크 |
|--------|------|------|
| 토지피복도 | 환경부 | https://egis.me.go.kr |
| DEM | 국토지리정보원 | https://map.ngii.go.kr |
| 병원 API | 국립중앙의료원 | https://www.data.go.kr/data/15000736/openapi.do |
| 건축물 API | 국토교통부 | https://www.data.go.kr/tcs/dss/selectApiDataDetailView.do?publicDataPk=15028022 |
| 기후 데이터 | CMIP6 | https://esgf-node.llnl.gov/projects/cmip6/ |

---

## ⚠️ 10. 주의사항

### 데이터 한계
1. **H (Hazard)**: 현재 하드코딩 값 사용 (실제 NetCDF 데이터 미연동)
2. **토지피복**: 1:50,000 축척 → 세밀한 분석에는 한계
3. **DEM**: 30m 해상도 → 미세한 지형 변화 반영 제한
4. **API 의존성**: 공공 API 장애 시 기본값 사용

### 개선 계획
- [ ] NetCDF 기후 데이터 실제 추출 및 분석
- [ ] 더 높은 해상도의 토지피복도 활용
- [ ] 시계열 분석 (과거~미래 트렌드)
- [ ] 공간 보간 정밀도 향상
- [ ] 지역난방 인프라 데이터 추가

---

## 📖 11. 참고 문헌

- TCFD (2017). *Recommendations of the Task Force on Climate-related Financial Disclosures*
- IPCC AR6 (2021). *Climate Change 2021: The Physical Science Basis*
- S&P Global (2021). *Physical Risk Exposure Ratings Methodology*

---

**작성일**: 2024-11-14
**버전**: 1.0
