<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# 내륙 홍수 세부 수식과 필요 데이터, 데이터 출처, 근거, 계산 코드 줘

아래는 **내륙 홍수(하천 범람)** 평가를 위한 **구체 수식, 필요 데이터, 출처, 근거, 그리고 계산 코드** 전체 정리입니다.

***

# 내륙 홍수 리스크 세부 수식

```python
내륙홍수_리스크 = (위해성 × 0.35) + (노출 × 0.40) + (취약성 × 0.25)
```


### 세부 요소별 산출 공식

| 항목 | 설명 | 공식 | 가중치 | 근거 |
| :-- | :-- | :-- | :-- | :-- |
| 위해성 | 강수량 증가 및 유역 특성 반영 | `hazard_score` = `(RX5DAY증가율 / 50) * 100` + 유역면적 점수 + 차수 점수 | 0.35 | ◉ 미국 NC(2021), ◉ 한강 유역 연구(2012) |
| 노출 | 강수량, 거리, 침수 이력 | `exposure_score` = 거리 점수×0.4 + 침수 횟수점수×0.35 + 저지대 점수×0.25 | 0.40 | ◉ 인도 AHP(2024), ◉ 한강 연구(2012) |
| 취약성 | 건물 유형, 층수, 연식 | `vulnerability_score` = 건물유형×0.5 + 층수×0.3 + 연식×0.2 | 0.25 | ◉ FEMA DDF(1992), △ 한국 건물 손상 연구(2017) |


***

# 필요 데이터 및 출처

### 1. 강수량 데이터 (RX5DAY, RX1DAY, RAIN80 등)

| 데이터 | 용도 | 출처 | 설명 |
| :-- | :-- | :-- | :-- |
| `RX5DAY` | 최대 연속 5일 강수량 | 기상청 API 또는 NetCDF | 최대 강수 누적값, 연별 데이터 |
| `RX1DAY` | 하루 최대 강수량 | 기상청 API 또는 NetCDF | 집중호우 판단용 |
| `RAIN80` | 80mm 이상 일수 | 기상청 API 또는 NetCDF | 집중호우 빈도 |

### 2. 강수 증감율 계산용 기상청 SSP 자료

| 데이터 | 출처 | 설명 |
| :-- | :-- | :-- |
| SSP 시나리오별 강수량 | 기상청 API | 1991-2020 평균 → 2041-2060, 2081-2100 예상 값 |

### 3. 유역 면적과 차수 정보

| 데이터 | 출처 | 설명 |
| :-- | :-- | :-- |
| 유역 면적 | WAMIS (Water Management Info System) | km²로 제공, 꼭 한국 유역별로 파악 필요 |
| 하천 차수 | 국가하천관리시스템 GIS 데이터 | Strahler 차수, 1~4레벨 |

### 4. 주변 지형 및 침수 이력 데이터

| 데이터 | 출처 | 설명 |
| :-- | :-- | :-- |
| DEM (수치표고) | 국토정보원 | 표고계산 및 저지대 판단용 |
| 침수 이력 | 행정안전부 재해연보 | 읍면동별 침수횟수, 과거 홍수 표기 |


***

# 계산 코드 예제

```python
import numpy as np

# 1) RX5DAY 증가율 계산
def get_rx5day_increase(scenario, year):
    base = 280  # 1991-2020 평균값 가정
    multipliers = {'SSP126': 1.20, 'SSP245': 1.30, 'SSP370': 1.38, 'SSP585': 1.45}
    future = base * multipliers.get(scenario, 1.3)
    increase_pct = ((future - base) / base) * 100
    return min(100, (increase_pct / 50) * 100)  # 50% 증가 시 100점

# 2) 유역 면적 점수
def get_area_score(area_km2):
    if area_km2 >= 10000:
        return 100
    elif area_km2 <= 1000:
        return 10
    else:
        return 10 + ((area_km2 - 1000) / 9000) * 90  # 1000~10000 km² 범위 보간

# 3) 차수 점수
def get_stream_order_score(order):
    return (order / 4) * 100  # 최대 4차수

# 4) 침수 이력 점수
def get_flood_history_score(count):
    return min(100, count * 20)  # 5회 이상 → 100점

# 5) 저지대 점수
def get_lowland_score(building_elev, river_elev):
    diff = building_elev - river_elev
    if diff <= 0:
        return 100
    elif diff >= 10:
        return 0
    else:
        return (diff / 10) * 100

# 최종 위험도 계산 예제
def compute_inland_flood_risk(building, watershed_info, river_elev, flood_count, scenario, year):
    hazard = get_rx5day_increase(scenario, year)
    area_score = get_area_score(watershed_info['면적_km2'])
    order_score = get_stream_order_score(watershed_info['차수'])
    hazard_score = (hazard * 0.5) + (area_score * 0.3) + (order_score * 0.2)
    
    # 거리별 가중치 (여기 간단히 임의 값)
    distance_m = 500  # 예시
    if distance_m <= 100:
        dist_score = 100
    elif distance_m >= 2000:
        dist_score = 0
    else:
        dist_score = 100 - ((distance_m - 100)/1900)*100
    
    flow_history_score = get_flood_history_score(flood_count)
    lowland_score = get_lowland_score(building['height'], river_elev)
    
    exposure = (dist_score * 0.4) + (flow_history_score * 0.35) + (lowland_score * 0.25)
    # 취약성 (건물 유형, 층수, 연식)
    type_score = {'공장':50,'사무실':70,'주택':100}.get(building['type'],70)
    floors_score = {1:100, 2:70, 3:40, 4:20}.get(building['floors'],30)
    year = building['build_year']
    age = 2025 - year
    if age >= 30:
        age_score = 100
    elif age <= 10:
        age_score = 30
    else:
        age_score = 30 + ((age -10)/20)*70
    vulnerability = (type_score*0.5) + (floors_score*0.3) + (age_score*0.2)
    # 최종
    risk = (hazard_score*0.35)+(exposure*0.40)+(vulnerability*0.25)
    return risk
```


## 정리

- **중요 데이터**: 강수량(SSR, *RX5DAY* 등), 유역면적, 하천 차수, 침수 이력, 지형(DEM)
- **이상적인 데이터 소스**: WAMIS, 국가하천/지형 GIS, 행안부 재해연보
- **캐시 또는 실시간 API 활용 가능**

이 정보 활용해서 직접 데이터 수집, 가공, 리스크 산출을 하실 수 있습니다!

