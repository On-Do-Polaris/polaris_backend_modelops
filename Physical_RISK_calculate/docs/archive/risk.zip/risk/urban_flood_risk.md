## 계산 로직

def calculate_pluvial_risk_without_drainage_data(building_info, ssp_scenario):
"""
배수망 데이터 없을 때: 불투수면 + TWI + 강수량
근거: 스페인 연구(2024, 27회 인용) - 정확도 85%
""" # ============================================================ # 1단계: 위해성 (동일) # ============================================================
위해성 = calculate_pluvial_hazard_score(location, ssp_scenario, target_year) # RX1DAY, SDII, RAIN80 사용 (기상청 데이터)

    # ============================================================
    # 2단계: 배수 포화도 (대체 방법)
    # ============================================================

    # 2-1. 불투수면 비율 (%) - 핵심 대리 변수
    # 근거: Nature(2025) - 불투수면 비율이 배수 용량의 역지표
    불투수면_비율 = get_impervious_ratio(
        lat=building_info['위도'],
        lon=building_info['경도'],
        radius=500,
        land_cover_data='korea_landcover_2024.tif'
    )

    # 정규화: 높을수록 위험
    불투수면_점수 = 불투수면_비율  # 80%=80점


    # 2-2. TWI (Topographic Wetness Index)
    # 근거: 일리노이 주정부(2023) - 물 고임 가능성 지표
    # TWI = ln(a / tan(β))
    # a = upslope area (상류 누적 면적)
    # β = local slope (경사)

    dem = load_dem('korea_dem_5m.tif')

    # Flow accumulation 계산
    flow_acc = calculate_flow_accumulation(dem, building_info['위도'], building_info['경도'])

    # Slope 계산
    slope = calculate_slope(dem, building_info['위도'], building_info['경도'])

    # TWI 계산
    if slope < 0.001:
        slope = 0.001  # 매우 평평한 지역 보정

    twi = np.log(flow_acc / np.tan(slope))

    # TWI 정규화: 9~27.5 범위가 위험 (일리노이 기준)
    if twi >= 20:
        twi_점수 = 100
    elif twi <= 5:
        twi_점수 = 0
    else:
        twi_점수 = ((twi - 5) / 15) * 100


    # 2-3. 인구밀도 (명/km²) - 간접 지표
    # 근거: 중국 연구(2023) - 인구밀도 높을수록 도시화=배수망 발달
    인구밀도 = get_population_density(building_info['읍면동코드'])

    # 역수 관계: 인구 많을수록 배수망 있을 가능성 높음
    if 인구밀도 >= 10000:
        인구_점수 = 20  # 고밀도 - 배수망 양호
    elif 인구밀도 <= 1000:
        인구_점수 = 80  # 저밀도 - 배수망 부족
    else:
        인구_점수 = 80 - ((인구밀도 - 1000) / 9000) * 60


    # 배수 포화도 대체 점수
    # 근거: 스페인 연구(2024) - 불투수(0.5) + TWI(0.35) + 인구(0.15)
    배수_포화도 = (불투수면_점수 * 0.5) + (twi_점수 * 0.35) + (인구_점수 * 0.15)


    # ============================================================
    # 3단계: 취약성 (단순화)
    # ============================================================
    # 지하층 + 저지대만 사용 (관거 거리 제외)
    지하층수 = building_info.get('지하층수', 0)
    지하층_점수 = min(100, 지하층수 * 40 + 20)

    건물_표고 = dem.get_elevation(building_info['위도'], building_info['경도'])
    주변_평균 = dem.get_avg_elevation_radius(building_info['위도'], building_info['경도'], 200)
    표고_차이 = 주변_평균 - 건물_표고
    저지대_점수 = min(100, max(0, (표고_차이 / 3) * 100))

    취약성 = (지하층_점수 * 0.6) + (저지대_점수 * 0.4)


    # ============================================================
    # 최종 리스크 점수
    # ============================================================
    도시홍수_리스크 = (위해성 * 0.30) + (배수_포화도 * 0.45) + (취약성 * 0.25)

    return 도시홍수_리스크

## 데이터

DEM, 토지피복도 데이터 보유
DEM : /Users/ichangmin/SKALA Final Project/polaris_practice_backend_v01/with_dh/folder_divided_good/Physical_RISK_calculate/shared_data/DEM
토지피복도: /Users/ichangmin/SKALA Final Project/polaris_practice_backend_v01/with_dh/folder_divided_good/Physical_RISK_calculate/shared_data/DEM

인구밀도
읍면동 단위 인구 수 API:

- 행정안전부*통계연보*지역별 주민등록인구 오픈API 활용
  - API 주소: https://apis.data.go.kr/1741000/RegistrationPopulationByRegion/getRegistrationPopulationByRegion
  - 주요 파라미터:
    - ServiceKey: 공공데이터포털에서 발급받은 인증키 (.env에 저장)
    - pageNo: 페이지 번호
    - numOfRows: 한 페이지 결과 수
  - 응답 데이터:
    - regi: 지역명(읍면동까지)
    - population_tot: 총인구
    - population_man: 남자 인구
    - population_female: 여자 인구
    - houshol: 세대수
    - wrttimeid: 통계 기준 시점
- 읍면동 코드로 해당 지역 인구수 조회 후,  
  읍면동별 면적 파일(N3A_G0110000)과 결합하여 인구밀도(명/km²) 산출

  읍면동별 면적: /Users/ichangmin/SKALA Final Project/polaris_practice_backend_v01/with_dh/folder_divided_good/Physical_RISK_calculate/shared_data/N3A_G0110000 참고

건축물대장 API:

- 국토교통부*건축HUB*건축물대장정보 오픈API

  - Base URL: https://apis.data.go.kr/1613000/BldRgstHubService

  - 공통 파라미터:

    - serviceKey: 공공데이터포털에서 발급받은 인증키 (.env에 저장)
    - sigunguCd: 시군구코드 (필수)
    - bjdongCd: 법정동코드 (필수)
    - platGbCd: 대지구분코드(0:대지, 1:산, 2:블록)
    - bun: 번
    - ji: 지
    - startDate: 검색시작일(YYYYMMDD)
    - endDate: 검색종료일(YYYYMMDD)
    - \_type: 응답 포맷(xml, json, 생략 시 xml)
    - numOfRows: 한 페이지 결과 수
    - pageNo: 페이지 번호

  - 주요 엔드포인트 및 설명:

    - /getBrTitleInfo

      - 건축물대장 표제부 조회
      - 주요 반환값: 지번/도로명 주소, 주/부속구분, 대지면적, 건축면적, 건폐율, 용적율, 구조, 용도, 지붕구조, 주차대수, 지상/지하층수 등

    - /getBrFlrOulnInfo

      - 건축물대장 층별개요 조회
      - 주요 반환값: 층구분, 층번호, 층의 구조, 용도, 면적 등

    - /getBrBasisOulnInfo

      - 건축물대장 기본개요 조회
      - 주요 반환값: 대장종류, 대장구분, 지번주소, 새주소, 지역/지구/구역 등

    - /getBrRecapTitleInfo

      - 건축물대장 총괄표제부 조회
      - 주요 반환값: 대지면적, 건축면적, 연면적, 건폐율, 용적율, 용도, 주차방식 및 주차대수, 부속건축물 면적, 허가관리기관, 에너지등급 등

    - /getBrExposPubuseAreaInfo

      - 건축물대장 전유공용면적 조회
      - 주요 반환값: 전유/공용구분, 구조, 용도, 면적 등

    - /getBrHsprcInfo

      - 건축물대장 주택가격 조회
      - 주요 반환값: 주택가격, 기준일 등

    - /getBrExposInfo

      - 건축물대장 전유부 조회
      - 주요 반환값: 동/호명칭, 주소 등

    - /getBrWclfInfo

      - 건축물대장 오수정화시설 조회
      - 주요 반환값: 오수정화형식, 용량, 용량단위 등

    - /getBrAtchJibunInfo

      - 건축물대장 부속지번 조회
      - 주요 반환값: 부속지번, 부속대장구분 등

    - /getBrJijiguInfo
      - 건축물대장 지역지구구역 조회
      - 주요 반환값: 지역/지구/구역 구분 및 명칭, 대표여부 등

  - 응답 데이터(공통 구조 예시):

    - header: resultCode, resultMsg
    - body:
      - items:
        - item: (각 엔드포인트별 상세 필드, 예: grndFlrCnt(지상층수), ugrndFlrCnt(지하층수), platArea(대지면적), archArea(건축면적), totArea(연면적), mainPurpsCdNm(주용도), strctCdNm(구조), useAprDay(사용승인일), bldNm(건물명), platPlc/newPlatPlc(지번/도로명 주소) 등)
      - numOfRows: 한 페이지 결과 수
      - pageNo: 페이지 번호
      - totalCount: 전체 결과 수

  - 참고:
    - 각 엔드포인트별로 필수 파라미터가 다를 수 있으니, 공식 문서 참고
    - 데이터 포맷은 XML/JSON 모두 지원
    - 상세 필드 및 예시는 공공데이터포털 API 문서에서 확인 가능
