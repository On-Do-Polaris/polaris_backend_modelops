🔥 3) Wildfire (산불)
✔ H
FWI (ERA5 기반 계산)
건조일수

✔ E
지표	데이터
산림면적 비율	토지피복도
경사도	DEM 
산불위험지도 등급	산림청 wildfire_calculate.md

✔ V
지표	데이터
소방서 접근성	NDMS      공공데이터 _ 소방청_전국소방서 좌표현황(XY좌표) firefighter.md
산업시설·야적장 존재 Proxy	토지피복도 있음
지하시설 여부	건축물대장 있음